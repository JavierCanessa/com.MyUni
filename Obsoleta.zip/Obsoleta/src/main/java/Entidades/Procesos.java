package Entidades;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author tocho
 */
public enum Procesos {

    Grupo_de_Whatsapp,
    Material_Estudio_CBC_Area_de_Salud,
    Convalidación_Titulo_Secundario,
    Compra_Pasajes_Aereos,
    Reserva_Alojamiento,
    Recepción_Aeropuerto,
    Entrega_Kit_Supervivencia,
    Pago_Boletas,
    Certificado_De_Domicilio,
    Cita_DNI,
    Precaria,
    DNI_Resuelto,
    Pre_inscripción,
    Busqueda_Laboral

}
