
package Tests;

import java.sql.Connection;
import java.sql.ResultSet;


public class TestConnection {

  
    public static void main(String[] args) {
        // TODO code application logic here
        try ( Connection conn=new Connectors.Connectors().getConnection() ) {
            ResultSet rs = conn.createStatement().executeQuery("select version()");
            if ( rs.next() ) { System.out.println(rs.getString(1)); }
            else { System.out.println("No hay Conexion"); }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
