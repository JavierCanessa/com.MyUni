use unistudent;
select * from listaclientes where cod = 459732124;

